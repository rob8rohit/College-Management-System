
package com.example.college.service;
import java.util.List;
import com.example.college.entity.Course;

public interface CourseService {
    List<Course> getAll();
    Course save(Course obj);
}
