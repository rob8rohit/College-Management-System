
package com.example.college.service;
import java.util.List;
import com.example.college.entity.Department;

public interface DepartmentService {
    List<Department> getAll();
    Department save(Department obj);
}
