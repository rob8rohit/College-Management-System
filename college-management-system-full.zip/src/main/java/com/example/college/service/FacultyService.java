
package com.example.college.service;
import java.util.List;
import com.example.college.entity.Faculty;

public interface FacultyService {
    List<Faculty> getAll();
    Faculty save(Faculty obj);
}
