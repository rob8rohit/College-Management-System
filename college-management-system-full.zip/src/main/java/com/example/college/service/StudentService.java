
package com.example.college.service;
import java.util.List;
import com.example.college.entity.Student;

public interface StudentService {
    List<Student> getAll();
    Student save(Student obj);
}
