
package com.example.college.controller;
import java.util.List;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import com.example.college.service.FacultyService;
import com.example.college.entity.Faculty;

@RestController
@RequestMapping("/api/facultys")
@RequiredArgsConstructor
public class FacultyController {
    private final FacultyService service;

    @GetMapping
    public List<Faculty> getAll() {
        return service.getAll();
    }

    @PostMapping
    public Faculty save(@RequestBody Faculty obj) {
        return service.save(obj);
    }
}
